# Landing Page HTML/CSS/JavaScript - Nutricionista

Esta pasta contém a versão em HTML puro, CSS e JavaScript da landing page para nutricionista.

## Arquivos Necessários

Crie 3 arquivos na mesma pasta:

### 1. index.html
### 2. style.css  
### 3. script.js

## Como usar

1. Copie o conteúdo de cada seção abaixo para os respectivos arquivos
2. Abra o arquivo `index.html` em um navegador
3. A página funcionará completamente offline

---

## ARQUIVO: index.html

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dra. Maria Silva - Nutricionista</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Hero Section -->
    <section id="hero" class="hero-section">
        <div class="hero-background">
            <img src="https://images.unsplash.com/photo-1490818387583-1baba5e638af?w=1080" alt="Fresh fruits">
            <div class="hero-overlay"></div>
        </div>

        <div class="container hero-content">
            <div class="hero-text">
                <h1 class="hero-title fade-in-up">Transforme Sua Saúde</h1>
                <p class="hero-subtitle fade-in-up delay-1">
                    Nutrição personalizada para o seu bem-estar. Descubra como uma alimentação equilibrada pode mudar sua vida.
                </p>
                <div class="hero-buttons fade-in-up delay-2">
                    <button class="btn btn-primary">Agende sua Consulta</button>
                    <button class="btn btn-secondary">Saiba Mais</button>
                </div>
            </div>
        </div>

        <div class="scroll-indicator">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M12 5v14M19 12l-7 7-7-7"/>
            </svg>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about-section">
        <div class="container">
            <div class="about-grid">
                <div class="about-image-wrapper fade-in-left">
                    <div class="about-image-bg"></div>
                    <img src="https://images.unsplash.com/photo-1585358682246-23acb1561f6b?w=1080" alt="Nutricionista" class="about-image">
                </div>

                <div class="about-content fade-in-right">
                    <h2 class="section-title">Conheça a Dra. Maria Silva</h2>
                    <p class="text-content">
                        Nutricionista clínica especializada em emagrecimento saudável e qualidade de vida.
                        Formada pela USP com pós-graduação em Nutrição Esportiva, dedico-me a transformar
                        a relação das pessoas com a alimentação.
                    </p>
                    <p class="text-content">
                        Acredito que cada pessoa é única e merece um plano alimentar personalizado que
                        respeite suas necessidades, preferências e estilo de vida.
                    </p>

                    <div class="stats-grid">
                        <div class="stat-item">
                            <div class="stat-icon">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                                    <circle cx="9" cy="7" r="4"/>
                                    <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>
                                </svg>
                            </div>
                            <div class="stat-value">500+</div>
                            <div class="stat-label">Pacientes Atendidos</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-icon">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <circle cx="12" cy="8" r="7"/>
                                    <polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/>
                                </svg>
                            </div>
                            <div class="stat-value">10+</div>
                            <div class="stat-label">Anos de Experiência</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-icon">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                                </svg>
                            </div>
                            <div class="stat-value">98%</div>
                            <div class="stat-label">Satisfação</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="services-section">
        <div class="container">
            <div class="section-header fade-in-up">
                <h2 class="section-title">O Que Eu Faço</h2>
                <p class="section-subtitle">Serviços especializados para cada necessidade e objetivo</p>
            </div>

            <div class="services-grid">
                <div class="service-card fade-in-up">
                    <div class="service-icon gradient-emerald">
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M5.5 8.5 9 12l-3.5 3.5L2 12l3.5-3.5zM12 2l3.5 3.5L12 9 8.5 5.5 12 2zM18.5 8.5 22 12l-3.5 3.5L15 12l3.5-3.5zM12 15l3.5 3.5L12 22l-3.5-3.5L12 15z"/>
                        </svg>
                    </div>
                    <h3 class="service-title">Emagrecimento Saudável</h3>
                    <p class="service-description">Planos alimentares personalizados para perda de peso sustentável e duradoura.</p>
                </div>

                <div class="service-card fade-in-up delay-1">
                    <div class="service-icon gradient-teal">
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"/>
                            <path d="M8 14s1.5 2 4 2 4-2 4-2"/>
                        </svg>
                    </div>
                    <h3 class="service-title">Nutrição Esportiva</h3>
                    <p class="service-description">Otimize seu desempenho atlético com estratégias nutricionais específicas.</p>
                </div>

                <div class="service-card fade-in-up delay-2">
                    <div class="service-icon gradient-rose">
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                        </svg>
                    </div>
                    <h3 class="service-title">Saúde do Coração</h3>
                    <p class="service-description">Prevenção e controle de doenças cardiovasculares através da alimentação.</p>
                </div>

                <div class="service-card fade-in-up delay-3">
                    <div class="service-icon gradient-amber">
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="8" r="5"/>
                            <path d="M3 21a9 9 0 0 1 18 0"/>
                        </svg>
                    </div>
                    <h3 class="service-title">Reeducação Alimentar</h3>
                    <p class="service-description">Transforme seus hábitos e construa uma relação saudável com a comida.</p>
                </div>

                <div class="service-card fade-in-up delay-4">
                    <div class="service-icon gradient-purple">
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                            <circle cx="12" cy="7" r="4"/>
                        </svg>
                    </div>
                    <h3 class="service-title">Nutrição Materno-Infantil</h3>
                    <p class="service-description">Acompanhamento nutricional para gestantes, lactantes e crianças.</p>
                </div>

                <div class="service-card fade-in-up delay-5">
                    <div class="service-icon gradient-indigo">
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M12 2v2m0 16v2M4.93 4.93l1.41 1.41m11.32 11.32l1.41 1.41M2 12h2m16 0h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>
                            <circle cx="12" cy="12" r="5"/>
                        </svg>
                    </div>
                    <h3 class="service-title">Estética e Bem-Estar</h3>
                    <p class="service-description">Nutrição para beleza da pele, cabelos e unhas, de dentro para fora.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section id="testimonials" class="testimonials-section">
        <div class="container">
            <div class="section-header fade-in-up">
                <h2 class="section-title">O Que Dizem Meus Pacientes</h2>
                <p class="section-subtitle">Histórias reais de transformação e sucesso</p>
            </div>

            <div class="testimonials-grid">
                <div class="testimonial-card fade-in-up">
                    <svg class="quote-icon" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"/>
                    </svg>
                    <div class="testimonial-header">
                        <img src="https://i.pravatar.cc/150?img=1" alt="Ana Paula">
                        <div>
                            <h4 class="testimonial-name">Ana Paula</h4>
                            <p class="testimonial-role">Perdeu 15kg</p>
                        </div>
                    </div>
                    <div class="testimonial-stars">
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                    </div>
                    <p class="testimonial-content">
                        "A Dra. Maria mudou completamente minha vida! Com o plano personalizado, perdi peso de forma saudável e aprendi a me alimentar melhor. Recomendo muito!"
                    </p>
                </div>

                <div class="testimonial-card fade-in-up delay-1">
                    <svg class="quote-icon" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"/>
                    </svg>
                    <div class="testimonial-header">
                        <img src="https://i.pravatar.cc/150?img=12" alt="Carlos Eduardo">
                        <div>
                            <h4 class="testimonial-name">Carlos Eduardo</h4>
                            <p class="testimonial-role">Atleta Amador</p>
                        </div>
                    </div>
                    <div class="testimonial-stars">
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                    </div>
                    <p class="testimonial-content">
                        "Como corredor, precisava de um plano nutricional que melhorasse meu desempenho. Os resultados foram incríveis! Bati meu recorde pessoal nos 10km."
                    </p>
                </div>

                <div class="testimonial-card fade-in-up delay-2">
                    <svg class="quote-icon" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"/>
                    </svg>
                    <div class="testimonial-header">
                        <img src="https://i.pravatar.cc/150?img=5" alt="Juliana Santos">
                        <div>
                            <h4 class="testimonial-name">Juliana Santos</h4>
                            <p class="testimonial-role">Gestante</p>
                        </div>
                    </div>
                    <div class="testimonial-stars">
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                    </div>
                    <p class="testimonial-content">
                        "O acompanhamento durante minha gravidez foi excepcional. Me senti cuidada e segura em todas as etapas. Meu bebê nasceu super saudável!"
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Location Section -->
    <section id="location" class="location-section">
        <div class="container">
            <div class="section-header fade-in-up">
                <h2 class="section-title">Localização e Contato</h2>
                <p class="section-subtitle">Venha nos visitar ou entre em contato para agendar sua consulta</p>
            </div>

            <div class="location-grid">
                <div class="location-info">
                    <div class="contact-card fade-in-left">
                        <div class="contact-icon gradient-emerald">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                                <circle cx="12" cy="10" r="3"/>
                            </svg>
                        </div>
                        <div>
                            <h3 class="contact-title">Endereço</h3>
                            <p class="contact-text">Av. Paulista, 1234 - Sala 567<br>São Paulo, SP</p>
                        </div>
                    </div>

                    <div class="contact-card fade-in-left delay-1">
                        <div class="contact-icon gradient-emerald">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                            </svg>
                        </div>
                        <div>
                            <h3 class="contact-title">Telefone</h3>
                            <p class="contact-text">(11) 98765-4321<br>(11) 3456-7890</p>
                        </div>
                    </div>

                    <div class="contact-card fade-in-left delay-2">
                        <div class="contact-icon gradient-emerald">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                                <polyline points="22,6 12,13 2,6"/>
                            </svg>
                        </div>
                        <div>
                            <h3 class="contact-title">Email</h3>
                            <p class="contact-text">contato@dramariasilva.com.br</p>
                        </div>
                    </div>

                    <div class="contact-card fade-in-left delay-3">
                        <div class="contact-icon gradient-emerald">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"/>
                                <polyline points="12 6 12 12 16 14"/>
                            </svg>
                        </div>
                        <div>
                            <h3 class="contact-title">Horário</h3>
                            <p class="contact-text">Segunda à Sexta: 8h - 19h<br>Sábado: 8h - 13h</p>
                        </div>
                    </div>
                </div>

                <div class="map-container fade-in-right">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.0977074745556!2d-46.65654!3d-23.561414!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce59c8da0aa315%3A0xd59f9431f2c9776a!2sAv.%20Paulista%2C%20S%C3%A3o%20Paulo%20-%20SP!5e0!3m2!1spt-BR!2sbr!4v1234567890"
                        width="100%"
                        height="100%"
                        style="border:0;"
                        allowfullscreen=""
                        loading="lazy">
                    </iframe>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-column">
                    <h3 class="footer-title">Dra. Maria Silva</h3>
                    <p class="footer-text">
                        Nutricionista dedicada a transformar vidas através da alimentação saudável e personalizada.
                    </p>
                </div>

                <div class="footer-column">
                    <h4 class="footer-heading">Links Rápidos</h4>
                    <ul class="footer-links">
                        <li><a href="#about">Sobre</a></li>
                        <li><a href="#services">Serviços</a></li>
                        <li><a href="#testimonials">Depoimentos</a></li>
                        <li><a href="#location">Contato</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h4 class="footer-heading">Informações</h4>
                    <ul class="footer-links">
                        <li>CRN: 12345/SP</li>
                        <li>Segunda à Sexta: 8h - 19h</li>
                        <li>Sábado: 8h - 13h</li>
                    </ul>
                </div>
            </div>

            <div class="footer-bottom">
                <p class="footer-love">
                    Feito com
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2">
                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                    </svg>
                    para sua saúde
                </p>
                <p class="footer-copyright">© 2026 Dra. Maria Silva - Todos os direitos reservados</p>
            </div>
        </div>
    </footer>

    <script src="script.js"></script>
</body>
</html>
```

O conteúdo dos arquivos CSS e JavaScript está muito longo para incluir aqui. Você encontrará os arquivos completos na pasta `/workspaces/default/code/html-version/` ou pode ver o arquivo `style.css` que já foi criado.

Para criar o arquivo `script.js`, copie o código JavaScript de animações e interatividade.
