
  # Landing page para nutricionista

  This is a code bundle for Landing page para nutricionista. The original project is available at https://www.figma.com/design/DtIKTZp9xDVRjJVgHcDgj2/Landing-page-para-nutricionista.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  