import { motion } from "motion/react";
import { Award, Heart, Users } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export default function About() {
  const stats = [
    { icon: Users, value: "500+", label: "Pacientes Atendidos" },
    { icon: Award, value: "10+", label: "Anos de Experiência" },
    { icon: Heart, value: "98%", label: "Satisfação" },
  ];

  return (
    <section id="about" className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-3xl transform rotate-3" />
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1585358682246-23acb1561f6b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxudXRyaXRpb25pc3QlMjBoZWFsdGh5JTIwZm9vZCUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3Nzg3NjgwODl8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Nutricionista"
                className="relative rounded-3xl w-full h-[500px] object-cover shadow-2xl"
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-5xl mb-6 text-gray-900">
              Conheça a Dra. Maria Silva
            </h2>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              Nutricionista clínica especializada em emagrecimento saudável e qualidade de vida.
              Formada pela USP com pós-graduação em Nutrição Esportiva, dedico-me a transformar
              a relação das pessoas com a alimentação.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Acredito que cada pessoa é única e merece um plano alimentar personalizado que
              respeite suas necessidades, preferências e estilo de vida.
            </p>

            <div className="grid grid-cols-3 gap-6">
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <stat.icon className="w-6 h-6 text-emerald-600" />
                  </div>
                  <div className="text-2xl text-emerald-600 mb-1">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
