import { motion } from "motion/react";
import { Star, Quote } from "lucide-react";

export default function Testimonials() {
  const testimonials = [
    {
      name: "Ana Paula",
      role: "Perdeu 15kg",
      content: "A Dra. Maria mudou completamente minha vida! Com o plano personalizado, perdi peso de forma saudável e aprendi a me alimentar melhor. Recomendo muito!",
      rating: 5,
      image: "https://i.pravatar.cc/150?img=1",
    },
    {
      name: "Carlos Eduardo",
      role: "Atleta Amador",
      content: "Como corredor, precisava de um plano nutricional que melhorasse meu desempenho. Os resultados foram incríveis! Bati meu recorde pessoal nos 10km.",
      rating: 5,
      image: "https://i.pravatar.cc/150?img=12",
    },
    {
      name: "Juliana Santos",
      role: "Gestante",
      content: "O acompanhamento durante minha gravidez foi excepcional. Me senti cuidada e segura em todas as etapas. Meu bebê nasceu super saudável!",
      rating: 5,
      image: "https://i.pravatar.cc/150?img=5",
    },
    {
      name: "Roberto Lima",
      role: "Controle de Diabetes",
      content: "Consegui controlar minha diabetes tipo 2 com as orientações da Dra. Maria. Minha glicemia está ótima e não preciso mais de tanta medicação.",
      rating: 5,
      image: "https://i.pravatar.cc/150?img=14",
    },
    {
      name: "Fernanda Costa",
      role: "Reeducação Alimentar",
      content: "Aprendi que alimentação saudável não precisa ser chata! Agora tenho uma relação muito melhor com a comida e me sinto muito mais disposta.",
      rating: 5,
      image: "https://i.pravatar.cc/150?img=9",
    },
    {
      name: "Lucas Mendes",
      role: "Ganho de Massa",
      content: "Consegui ganhar massa muscular de forma saudável com o plano da Dra. Maria. Ela entende muito de nutrição esportiva!",
      rating: 5,
      image: "https://i.pravatar.cc/150?img=13",
    },
  ];

  return (
    <section id="testimonials" className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl mb-4 text-gray-900">
            O Que Dizem Meus Pacientes
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Histórias reais de transformação e sucesso
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-gradient-to-br from-emerald-50 to-teal-50 p-8 rounded-2xl relative"
            >
              <Quote className="absolute top-6 right-6 w-12 h-12 text-emerald-200" />

              <div className="flex items-center mb-4">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-16 h-16 rounded-full object-cover mr-4 border-4 border-white shadow-lg"
                />
                <div>
                  <h4 className="text-lg text-gray-900">{testimonial.name}</h4>
                  <p className="text-sm text-emerald-600">{testimonial.role}</p>
                </div>
              </div>

              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                ))}
              </div>

              <p className="text-gray-700 leading-relaxed italic">
                "{testimonial.content}"
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
