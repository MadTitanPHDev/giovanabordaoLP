import { Heart } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="text-2xl mb-4 bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
              Dra. Maria Silva
            </h3>
            <p className="text-gray-400 leading-relaxed">
              Nutricionista dedicada a transformar vidas através da alimentação saudável e personalizada.
            </p>
          </div>

          <div>
            <h4 className="text-lg mb-4">Links Rápidos</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#about" className="hover:text-emerald-400 transition-colors">Sobre</a></li>
              <li><a href="#services" className="hover:text-emerald-400 transition-colors">Serviços</a></li>
              <li><a href="#testimonials" className="hover:text-emerald-400 transition-colors">Depoimentos</a></li>
              <li><a href="#location" className="hover:text-emerald-400 transition-colors">Contato</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg mb-4">Informações</h4>
            <ul className="space-y-2 text-gray-400">
              <li>CRN: 12345/SP</li>
              <li>Segunda à Sexta: 8h - 19h</li>
              <li>Sábado: 8h - 13h</li>
              <li>Atendimento presencial e online</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 text-center">
          <p className="text-gray-400 flex items-center justify-center gap-2">
            Feito com <Heart className="w-4 h-4 text-emerald-500 fill-emerald-500" /> para sua saúde
          </p>
          <p className="text-gray-500 text-sm mt-2">
            © 2026 Dra. Maria Silva - Todos os direitos reservados
          </p>
        </div>
      </div>
    </footer>
  );
}
