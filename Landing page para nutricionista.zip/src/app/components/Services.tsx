import { motion } from "motion/react";
import { Apple, Dumbbell, Heart, Scale, Baby, Sparkles } from "lucide-react";

export default function Services() {
  const services = [
    {
      icon: Scale,
      title: "Emagrecimento Saudável",
      description: "Planos alimentares personalizados para perda de peso sustentável e duradoura.",
      color: "from-emerald-500 to-teal-500",
    },
    {
      icon: Dumbbell,
      title: "Nutrição Esportiva",
      description: "Otimize seu desempenho atlético com estratégias nutricionais específicas.",
      color: "from-teal-500 to-cyan-500",
    },
    {
      icon: Heart,
      title: "Saúde do Coração",
      description: "Prevenção e controle de doenças cardiovasculares através da alimentação.",
      color: "from-rose-500 to-pink-500",
    },
    {
      icon: Apple,
      title: "Reeducação Alimentar",
      description: "Transforme seus hábitos e construa uma relação saudável com a comida.",
      color: "from-amber-500 to-orange-500",
    },
    {
      icon: Baby,
      title: "Nutrição Materno-Infantil",
      description: "Acompanhamento nutricional para gestantes, lactantes e crianças.",
      color: "from-purple-500 to-violet-500",
    },
    {
      icon: Sparkles,
      title: "Estética e Bem-Estar",
      description: "Nutrição para beleza da pele, cabelos e unhas, de dentro para fora.",
      color: "from-indigo-500 to-blue-500",
    },
  ];

  return (
    <section id="services" className="py-24 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl mb-4 text-gray-900">
            O Que Eu Faço
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Serviços especializados para cada necessidade e objetivo
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -8 }}
              className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all"
            >
              <div className={`w-16 h-16 bg-gradient-to-br ${service.color} rounded-2xl flex items-center justify-center mb-6 transform rotate-3`}>
                <service.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl mb-3 text-gray-900">
                {service.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
